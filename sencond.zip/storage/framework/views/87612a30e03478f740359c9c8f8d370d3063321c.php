<?php $__env->startSection('title'); ?> التدوينات | عرض <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">التدوينات</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-left">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>">الرئيسية</a></li>
                        <li class="breadcrumb-item active">التدوينات</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
        <div class="card">

            <!-- /.card-header -->
            <div class="card-body">
                <?php if(Session::has('message')): ?>
                    <div class="flash-notice alert alert-success">
                        <?php echo e(Session::get('message')); ?>

                    </div>
                <?php endif; ?>
                <?php if($rows->count() > 0): ?>
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <th>الاسم</th>
                                <th>بواسطة</th>
                                <th>التحكم</th>
                            </tr>
                                <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($row->title); ?></td>
                                        <td><?php echo e($row->admin->name); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('admin.blogs.destroy',$row->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <?php if(auth()->guard('admin')->user()->can('update_blogs')): ?>
                                                    <a href="<?php echo e(route('admin.blogs.edit',$row->id)); ?>" class="btn btn-success btn-sm"><i class="fa fa-edit"></i></a>
                                                <?php else: ?>
                                                    <a href="##" class="btn btn-success btn-sm disabled"><i class="fa fa-edit"></i></a>
                                                <?php endif; ?>
                                                <?php if(auth()->guard('admin')->user()->can('delete_blogs')): ?>
                                                    <button class="btn btn-danger btn-sm" onclick="return confirm('هل انت متأكد من الحذف')"><i class="fa fa-trash"></i></button>
                                                <?php else: ?>
                                                    <a href="##" class="btn btn-danger btn-sm disabled"><i class="fa fa-trash"></i></a>
                                                <?php endif; ?>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <h1>مفيش تدوينات</h1>
                    <?php if(auth()->guard('admin')->user()->can('create_blogs')): ?>
                        <a href="<?php echo e(route('admin.blogs.create')); ?>" class="btn btn-warning"><i class="fa fa-plus"></i> ضيف تدوينة من هنا</a>
                    <?php else: ?>
                        <a href="" class="btn btn-warning disabled"><i class="fa fa-plus"></i> ضيف تدوينة من هنا</a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <!-- /.card-body -->
            <div class="card-footer clearfix">


            </div>

        </div>
        <!-- /.card -->
    </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        var current = $('.pagination .current').text();
        $('.pagination span').addClass('page-item');
        $('.pagination span a').addClass('page-link');
        $('.pagination .current').html('<a class="page-link">' + current + '</a>');
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/laravel_blog/resources/views/admin/blogs/index.blade.php ENDPATH**/ ?>