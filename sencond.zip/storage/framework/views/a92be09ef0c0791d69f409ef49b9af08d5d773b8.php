<?php $__env->startSection('title'); ?> لوحة التحكم | الرئيسية <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">المشرفين</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-left">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>">الرئيسية</a></li>
                        <li class="breadcrumb-item active">المشرفين</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">جدول المشرفين</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">

                <?php if(Session::has('message')): ?>
                    <div class="flash-notice alert alert-success">
                            <?php echo e(Session::get('message')); ?>

                    </div>
                <?php endif; ?>

                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <th>الاسم</th>
                            <th>التحكم</th>
                        </tr>
                        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->name); ?></td>
                                <td>
                                    <?php if(auth()->guard('admin')->user()->can('update_admins')): ?>
                                        <a href="<?php echo e(route('admin.admins.edit',$row->id)); ?>" class="btn btn-success btn-sm"><i class="fa fa-edit"></i></a>
                                    <?php else: ?>
                                        <a href="##" class="btn btn-success btn-sm disabled"><i class="fa fa-edit"></i></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
            <div class="card-footer clearfix">








            </div>

        </div>
        <!-- /.card -->
    </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        var current = $('.pagination .current').text();
        $('.pagination span').addClass('page-item');
        $('.pagination span a').addClass('page-link');
        $('.pagination .current').html('<a class="page-link">' + current + '</a>');
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/laravel_blog/resources/views/admin/admins/index.blade.php ENDPATH**/ ?>