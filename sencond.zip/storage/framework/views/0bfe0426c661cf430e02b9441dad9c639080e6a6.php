<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <?php echo $__env->yieldContent('meta'); ?>
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Google font -->
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:700%7CNunito:300,600" rel="stylesheet">

    <!-- Bootstrap -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/front')); ?>/css/bootstrap.min.css"/>
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/front')); ?>/css/bootstrap-rtl.css"/>

    <!-- Font Awesome Icon -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/front')); ?>/css/font-awesome.min.css">

    <!-- Custom stlylesheet -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/front')); ?>/css/style.css"/>
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/front')); ?>/css/style-rtl.css"/>

    <link href="https://fonts.googleapis.com/css?family=Cairo:400,700" rel="stylesheet">
    <style>
        body, h1, h2, h3, h4, h5, h6 , #nav-aside .section-row ul li a{
            font-family: 'Cairo', sans-serif !important;
        }
    </style>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>
<!-- Header -->
<header id="header">
    <!-- Nav -->
    <div id="nav">
        <!-- Main Nav -->
        <div id="nav-fixed">
            <div class="container">
                <!-- logo -->
                <div class="nav-logo">
                    <a href="<?php echo e(route('front.index')); ?>" title="<?php echo e(route('front.index')); ?>" class="logo"><img src="<?php echo e(asset('assets/front')); ?>/img/logo.png" style="width: 114px;height: 32.4px;" title="مدونة السينيور" alt="مدونة السينيور"></a>
                </div>
                <!-- /logo -->

                <!-- nav -->
                <ul class="nav-menu nav navbar-nav">
                    <li><a href="<?php echo e(route('front.index')); ?>" title="الرئيسية">الرئيسية</a></li>

                    <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="<?php echo e($color[array_rand($color)]); ?>"><a href="<?php echo e(route('front.category',['id'=>$cat->id,'title'=>str_replace(' ','-',$cat->name)])); ?>" title="<?php echo e($cat->name); ?>"><?php echo e($cat->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <!-- /nav -->

                <!-- search & aside toggle -->
                <div class="nav-btns">
                    <button class="aside-btn"><i class="fa fa-bars"></i></button>
                    <button class="search-btn"><i class="fa fa-search"></i></button>
                    <div class="search-form">
                        <input class="search-input" type="text" name="search" placeholder="ابحث من هنا ...">
                        <button class="search-close"><i class="fa fa-times"></i></button>
                    </div>
                </div>
                <!-- /search & aside toggle -->
            </div>
        </div>
        <!-- /Main Nav -->

        <!-- Aside Nav -->
        <div id="nav-aside">
            <!-- nav -->
            <div class="section-row">
                <ul class="nav-aside-menu">
                    <li><a href="<?php echo e(route('front.index')); ?>">الرئيسية</a></li>
                    <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="<?php echo e($color[array_rand($color)]); ?>"><a href="<?php echo e(route('front.category',['id'=>$cat->id,'title'=>str_replace(' ','-',$cat->name)])); ?>" title="<?php echo e($cat->name); ?>"><?php echo e($cat->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <!-- /nav -->

            <!-- widget posts -->
            <div class="section-row">
                <h3>المقالات الاحدث</h3>
                <?php $__currentLoopData = $secondRecentBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondRecentBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="post post-widget">
                    <a class="post-img" href="<?php echo e(route('front.blog',["id"=>$secondRecentBlog->id,"title"=>$secondRecentBlog->title])); ?>" title="<?php echo e($secondRecentBlog->title); ?>"><img src="<?php echo e(asset('uploads/blogs/'.$secondRecentBlog->photo)); ?>" style="width: 90px;height: 54px;" title="<?php echo e($secondRecentBlog->title); ?>" alt="<?php echo e($secondRecentBlog->title); ?>"></a>
                    <div class="post-body">
                        <h3 class="post-title"><a href="<?php echo e(route('front.blog',["id"=>$secondRecentBlog->id,"title"=>$secondRecentBlog->title])); ?>" title="<?php echo e($secondRecentBlog->title); ?>"><?php echo e($secondRecentBlog->title); ?></a></h3>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- /widget posts -->

            <!-- social links -->
            <div class="section-row">
                <h3>تابعنا</h3>
                <ul class="nav-aside-social">
                    <li><a href="#" rel="nofollow"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#" rel="nofollow"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#" rel="nofollow"><i class="fa fa-google-plus"></i></a></li>
                    <li><a href="#" rel="nofollow"><i class="fa fa-pinterest"></i></a></li>
                </ul>
            </div>
            <!-- /social links -->

            <!-- aside nav close -->
            <button class="nav-aside-close"><i class="fa fa-times"></i></button>
            <!-- /aside nav close -->
        </div>
        <!-- Aside Nav -->
    </div>
    <!-- /Nav -->
</header>
<!-- /Header -->
<?php echo $__env->yieldContent('content'); ?>
<!-- Footer -->
<footer id="footer">
    <!-- container -->
    <div class="container">
        <!-- row -->
        <div class="row">
            <div class="col-md-5">
                <div class="footer-widget">
                    <div class="footer-logo">
                        <a href="<?php echo e(route('front.index')); ?>" class="logo"><img src="<?php echo e(asset('assets/front')); ?>/img/logo.png" title="مدونة السينيور" alt="مدونة السينيور"></a>
                    </div>




                    <div class="footer-copyright">
								<span>&copy; <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
حقوق النشر &copy;<script>document.write(new Date().getFullYear());</script> جميع الحقوق محفوظة <i class="fa fa-heart-o" aria-hidden="true"></i> بواسطة <a href="http://abdelrahman-osama.epizy.com/" target="_blank">Abdelrahman osama</a>
                                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></span>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="row">
                    <div class="col-md-6">
                        <div class="footer-widget">
                            <h3 class="footer-title">من نحن</h3>
                            <ul class="footer-links">
                                <li><a href="#" rel="nofollow">من نحن</a></li>
                                <li><a href="#" rel="nofollow">انضم الينا</a></li>
                                <li><a href="#" rel="nofollow">تواصل معنا</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="footer-widget">
                            <h3 class="footer-title">الاقسام</h3>
                            <ul class="footer-links">
                                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(route('front.category',['id'=>$cat->id,'title'=>str_replace(' ','-',$cat->name)])); ?>" title="<?php echo e($cat->name); ?>"><?php echo e($cat->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="footer-widget">
                    <h3 class="footer-title">ارسل لي الجديد</h3>
                    <div class="footer-newsletter">
                        <form>
                            <input class="input" type="email" name="newsletter" placeholder="ادخل بريدك الالكتروني">
                            <button class="newsletter-btn"><i class="fa fa-paper-plane"></i></button>
                        </form>
                    </div>
                    <ul class="footer-social">
                        <li><a href="#" rel="nofollow"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#" rel="nofollow"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#" rel="nofollow"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#" rel="nofollow"><i class="fa fa-pinterest"></i></a></li>
                    </ul>
                </div>
            </div>

        </div>
        <!-- /row -->
    </div>
    <!-- /container -->
</footer>
<!-- /Footer -->

<!-- jQuery Plugins -->
<script src="<?php echo e(asset('assets/front')); ?>/js/jquery.min.js"></script>
<script src="<?php echo e(asset('assets/front')); ?>/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('assets/front')); ?>/js/main.js"></script>

</body>
</html>
<?php /**PATH /opt/lampp/htdocs/laravel_blog/resources/views/front/layouts/app.blade.php ENDPATH**/ ?>