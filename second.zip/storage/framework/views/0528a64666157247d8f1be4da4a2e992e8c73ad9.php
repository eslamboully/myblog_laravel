<?php $__env->startSection('title'); ?> السنيور | الرئيسية <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- section -->
    <?php $color = ['cat-1','cat-2','cat-3','cat-4']; ?>
    <div class="section">
        <!-- container -->
        <div class="container">
            <!-- row -->

            <!-- /row -->

            <!-- row -->
            <div class="row">
                <div class="col-md-8">
                    <div class="row">
                        <!-- post -->
                        <div class="col-md-12">
                            <div class="post post-thumb">
                                <a class="post-img" href="<?php echo e(route('front.blog',["id"=>$recentBlog->id,"title"=>str_replace(' ','-',$recentBlog->title)])); ?>" title="<?php echo e($recentBlog->title); ?>"><img src="<?php echo e(asset('uploads/blogs/'.$recentBlog->photo)); ?>" style="width: 750px;height: 450px" title="<?php echo e($recentBlog->title); ?>" alt="<?php echo e($recentBlog->title); ?>"></a>
                                <div class="post-body">
                                    <div class="post-meta">
                                        <a class="post-category <?php echo e($color[array_rand($color)]); ?>" href="<?php echo e(route('front.category',["id"=>$recentBlog->category->id,"title"=>str_replace(' ','-',$recentBlog->category->name)])); ?>" title="<?php echo e($recentBlog->title); ?>"><?php echo e($recentBlog->category->name); ?></a>
                                        <span class="post-date"><?php echo e($recentBlog->created_at->diffForHumans()); ?></span>
                                    </div>
                                    <h3 class="post-title"><a href="<?php echo e(route('front.blog',["id"=>$recentBlog->id,"title"=>str_replace(' ','-',$recentBlog->title)])); ?>" title="<?php echo e($recentBlog->title); ?>"><?php echo e($recentBlog->title); ?></a></h3>
                                </div>
                            </div>
                        </div>
                        <!-- /post -->

                        <?php $__currentLoopData = $secondRecentBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondRecentBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- post -->
                            <div class="col-md-6">
                                <div class="post">
                                    <a class="post-img" title="<?php echo e($secondRecentBlog->title); ?>" href="<?php echo e(route('front.blog',["id"=>$secondRecentBlog->id,"title"=>str_replace(' ','-',$secondRecentBlog->title)])); ?>"><img src="<?php echo e(asset('uploads/blogs/'.$secondRecentBlog->photo)); ?>" style="width: 360px;height: 216px;" title="<?php echo e($secondRecentBlog->title); ?>" alt="<?php echo e($secondRecentBlog->title); ?>"></a>
                                    <div class="post-body">
                                        <div class="post-meta">
                                            <a class="post-category <?php echo e($color[array_rand($color)]); ?>" title="<?php echo e($secondRecentBlog->category->name); ?>" href="<?php echo e(path('front.category',["id"=>$secondRecentBlog->category->id,"title"=>$secondRecentBlog->category->name])); ?>" title="<?php echo e($secondRecentBlog->category->name); ?>"><?php echo e($secondRecentBlog->category->name); ?></a>
                                            <span class="post-date"><?php echo e($secondRecentBlog->created_at->diffForHumans()); ?></span>
                                        </div>
                                        <h3 class="post-title"><a href="<?php echo e(route('front.blog',["id"=>$secondRecentBlog->id,"title"=>str_replace(' ','-',$secondRecentBlog->title)])); ?>" title="<?php echo e($secondRecentBlog->category->name); ?>"><?php echo e($secondRecentBlog->title); ?></a></h3>
                                    </div>
                                </div>
                            </div>
                        <!-- /post -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="clearfix visible-md visible-lg"></div>

                        <?php $__currentLoopData = $thirdRecentBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thirdRecentBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- post -->
                            <div class="col-md-6">
                                <div class="post">
                                    <a class="post-img" title="<?php echo e($thirdRecentBlog->title); ?>" href="<?php echo e(route('front.blog',["id"=>$thirdRecentBlog->id,"title"=>str_replace(' ','-',$thirdRecentBlog->title)])); ?>"><img src="<?php echo e(asset('uploads/blogs/'.$thirdRecentBlog->photo)); ?>" style="width: 360px;height: 216px;" title="<?php echo e($thirdRecentBlog->title); ?>" alt="<?php echo e($thirdRecentBlog->title); ?>"></a>
                                    <div class="post-body">
                                        <div class="post-meta">
                                            <a class="post-category <?php echo e($color[array_rand($color)]); ?>" title="<?php echo e($thirdRecentBlog->category->name); ?>" href="<?php echo e(path('front.category',["id"=>$thirdRecentBlog->category->id,"title"=>$thirdRecentBlog->category->name])); ?>" title="<?php echo e($thirdRecentBlog->category->name); ?>"><?php echo e($thirdRecentBlog->category->name); ?></a>
                                            <span class="post-date"><?php echo e($thirdRecentBlog->created_at->diffForHumans()); ?></span>
                                        </div>
                                        <h3 class="post-title"><a href="<?php echo e(route('front.blog',["id"=>$thirdRecentBlog->id,"title"=>str_replace(' ','-',$thirdRecentBlog->title)])); ?>" title="<?php echo e($thirdRecentBlog->category->name); ?>"><?php echo e($thirdRecentBlog->title); ?></a></h3>
                                    </div>
                                </div>
                            </div>
                            <!-- /post -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="clearfix visible-md visible-lg"></div>

                        <?php $__currentLoopData = $forthRecentBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forthRecentBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- post -->
                            <div class="col-md-6">
                                <div class="post">
                                    <a class="post-img" title="<?php echo e($forthRecentBlog->title); ?>" href="<?php echo e(route('front.blog',["id"=>$forthRecentBlog->id,"title"=>str_replace(' ','-',$forthRecentBlog->title)])); ?>"><img src="<?php echo e(asset('uploads/blogs/'.$forthRecentBlog->photo)); ?>" style="width: 360px;height: 216px;" title="<?php echo e($forthRecentBlog->title); ?>" alt="<?php echo e($forthRecentBlog->title); ?>"></a>
                                    <div class="post-body">
                                        <div class="post-meta">
                                            <a class="post-category <?php echo e($color[array_rand($color)]); ?>" title="<?php echo e($forthRecentBlog->category->name); ?>" href="<?php echo e(path('front.category',["id"=>$forthRecentBlog->category->id,"title"=>$forthRecentBlog->category->name])); ?>" title="<?php echo e($forthRecentBlog->category->name); ?>"><?php echo e($forthRecentBlog->category->name); ?></a>
                                            <span class="post-date"><?php echo e($forthRecentBlog->created_at->diffForHumans()); ?></span>
                                        </div>
                                        <h3 class="post-title"><a href="<?php echo e(route('front.blog',["id"=>$forthRecentBlog->id,"title"=>str_replace(' ','-',$forthRecentBlog->title)])); ?>" title="<?php echo e($forthRecentBlog->category->name); ?>"><?php echo e($forthRecentBlog->title); ?></a></h3>
                                    </div>
                                </div>
                            </div>
                            <!-- /post -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="col-md-4">
                    <!-- post widget -->
                    <div class="aside-widget">
                        <div class="section-title">
                            <h2>الاكثر مشاهدة</h2>
                        </div>

                        <?php $__currentLoopData = $mostWatchBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mostWatchBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="post post-widget">
                                <a class="post-img" title="<?php echo e($mostWatchBlog->title); ?>" href="<?php echo e(route('front.blog',["id"=>$mostWatchBlog->id,"title"=>str_replace(' ','-',$mostWatchBlog->title)])); ?>"><img src="<?php echo e(asset('uploads/blogs/'.$mostWatchBlog->photo)); ?>" style="width: 360px;height: 216px;" title="<?php echo e($mostWatchBlog->title); ?>" alt="<?php echo e($mostWatchBlog->title); ?>"></a>
                            <div class="post-body">
                                <h3 class="post-title"><a href="<?php echo e(route('front.blog',["id"=>$mostWatchBlog->id,"title"=>str_replace(' ','-',$mostWatchBlog->title)])); ?>" title="<?php echo e($mostWatchBlog->category->name); ?>"><?php echo e($mostWatchBlog->title); ?></a></h3>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- /post widget -->

                    <!-- post widget -->
                    <div class="aside-widget">
                        <div class="section-title">
                            <h2>التدوينات المميزة</h2>
                        </div>
                        <?php $__currentLoopData = $secondMostWatchBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondMostWatchBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="post post-thumb">
                            <a class="post-img" href="<?php echo e(route('front.blog',["id"=>$secondMostWatchBlog->id,"title"=>$secondMostWatchBlog->title])); ?>" title="<?php echo e($secondMostWatchBlog->title); ?>"><img src="<?php echo e(asset('uploads/blogs/'.$secondMostWatchBlog->photo)); ?>" style="width: 90px;height: 54px;" title="<?php echo e($secondMostWatchBlog->title); ?>" alt="<?php echo e($secondMostWatchBlog->title); ?>"></a>
                            <div class="post-body">
                                <div class="post-meta">
                                    <a class="post-category <?php echo e($color[array_rand($color)]); ?>" href="<?php echo e(route('front.category',["id"=>$secondMostWatchBlog->category->id,"title"=>str_replace(' ','-',$secondMostWatchBlog->category->name)])); ?>" title="<?php echo e($secondMostWatchBlog->category->name); ?>"><?php echo e($secondMostWatchBlog->category->name); ?></a>
                                    <span class="post-date"><?php echo e($secondMostWatchBlog->created_at->diffForHumans()); ?></span>
                                </div>
                                <h3 class="post-title"><a href="<?php echo e(route('front.blog',["id"=>$secondMostWatchBlog->id,"title"=>$secondMostWatchBlog->title])); ?>" title="<?php echo e($secondMostWatchBlog->title); ?>"><?php echo e($secondMostWatchBlog->title); ?></a></h3>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- /post widget -->

                    <!-- ad -->
                    <div class="aside-widget text-center">
                        <a href="#" style="display: inline-block;margin: auto;">
                            <img class="img-responsive" src="<?php echo e(asset('assets/front')); ?>/img/ad-1.jpg" alt="">
                        </a>
                    </div>
                    <!-- /ad -->
                </div>
            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </div>
    <!-- /section -->

    <!-- section -->

    <!-- /section -->

    <!-- section -->
    <div class="section">
        <!-- container -->
        <div class="container">
            <!-- row -->
            <div class="row">
                <div class="col-md-8">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="section-title">
                                <h2>الاكثر قراءة</h2>
                            </div>
                        </div>




















                        <div class="col-md-12">
                            <div class="section-row">
                                <button class="primary-button center-block">رؤية المزيد</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <!-- ad -->
                    <div class="aside-widget text-center">
                        <a href="#" style="display: inline-block;margin: auto;">
                            <img class="img-responsive" src="<?php echo e(asset('assets/front')); ?>/img/ad-1.jpg" alt="">
                        </a>
                    </div>
                    <!-- /ad -->

                    <!-- catagories -->
                    <div class="aside-widget">
                        <div class="section-title">
                            <h2>الاقسام</h2>
                        </div>
                        <div class="category-widget">
                            <ul>
                                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('front.category',['id'=>$cat->id,'title'=>str_replace(' ','-',$cat->name)])); ?>" title="<?php echo e($cat->name); ?>"><?php echo e($cat->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <!-- /catagories -->

                    <!-- tags -->















                    <!-- /tags -->
                </div>
            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </div>
    <!-- /section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/laravel_blog/resources/views/front/index.blade.php ENDPATH**/ ?>