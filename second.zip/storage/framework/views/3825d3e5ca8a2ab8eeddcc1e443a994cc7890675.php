<?php $__env->startSection('title'); ?> السنيور | <?php echo e($blog->title); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('meta'); ?>
    <meta name="description" content="<?php echo e(\Illuminate\Support\Str::limit($blog->description,20)); ?>">
    <meta name="keywords" content="<?php echo e($blog->keyword); ?>">
    <meta name="title" content="<?php echo e($blog->title); ?>">
    <meta charset="utf-8"/>
    <meta name="author" content="abdelrahman osama ahmed aleslamboully" />
    <meta name="copyright" content="abdelrahman osama" />

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <div id="post-header" class="page-header">
        <div class="background-img" style="background-image: url('<?php echo e(asset('uploads/blogs/'.$blog->photo)); ?>');"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-10">
                    <div class="post-meta">
                        <a class="post-category cat-2" href="<?php echo e(route('front.category',["id"=>$blog->category->id,"title"=>str_replace(' ','-',$blog->category->name)])); ?>" title="<?php echo e($blog->category->name); ?>"><?php echo e($blog->category->name); ?></a>
                        <span class="post-date"><?php echo e($blog->created_at->diffForHumans()); ?></span>
                    </div>
                    <h1><?php echo e($blog->title); ?></h1>
                </div>
            </div>
        </div>
    </div>
    <!-- /Page Header -->

    <!-- section -->
    <div class="section">
        <!-- container -->
        <div class="container">
            <!-- row -->
            <div class="row">
                <!-- Post content -->
                <div class="col-md-8">
                    <div class="section-row sticky-container">
                        <div class="main-post">
                            <?php echo $blog->description; ?>

                        </div>
                        <div class="post-shares sticky-shares">

                            <script src="https://apps.elfsight.com/p/platform.js"  defer></script>
                            <div class="elfsight-app-fd8de85c-f4e7-46cd-8b6c-0679bee92ad9"></div>
                        </div>
                    </div>


                    <!-- ad -->
                    <div class="section-row text-center">
                        <a href="#" style="display: inline-block;margin: auto;">
                            <img class="img-responsive" src="<?php echo e(asset('assets/front')); ?>/img/ad-2.jpg" alt="">
                        </a>
                    </div>
                    <!-- ad -->

                    <!-- author -->
                    <div class="section-row">
                        <div class="post-author">
                            <div class="media">
                                <div class="media-left">
                                    <?php if($blog->admin->photo): ?>
                                        <img class="media-object" src="<?php echo e(asset('uploads/admins/'.$blog->admin->photo)); ?>" style="width: 120px;height: 120px;" title="<?php echo e($blog->admin->name); ?>" alt="<?php echo e($blog->admin->name); ?>">
                                    <?php else: ?>
                                        <img class="media-object" src="<?php echo e(asset('assets/admin/images')); ?>/profile.png" style="width: 120px;height: 120px;" title="<?php echo e($blog->admin->name); ?>" alt="<?php echo e($blog->admin->name); ?>">
                                    <?php endif; ?>
                                </div>
                                <div class="media-body">
                                    <div class="media-heading">
                                        <h3><?php echo e($blog->admin->name); ?></h3>
                                    </div>
                                    <p><?php echo e($blog->admin->description); ?></p>
                                    <ul class="author-social">
                                        <li><a href="#" rel="nofollow"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="#" rel="nofollow"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#" rel="nofollow"><i class="fa fa-google-plus"></i></a></li>
                                        <li><a href="#" rel="nofollow"><i class="fa fa-instagram"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /author -->


                    <div id="disqus_thread"></div>
                    <script>

                        /**
                         *  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
                         *  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables*/
                        /*
                        var disqus_config = function () {
                        this.page.url = PAGE_URL;  // Replace PAGE_URL with your page's canonical URL variable
                        this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
                        };
                        */
                        (function() { // DON'T EDIT BELOW THIS LINE
                            var d = document, s = d.createElement('script');
                            s.src = 'https://senior-2.disqus.com/embed.js';
                            s.setAttribute('data-timestamp', +new Date());
                            (d.head || d.body).appendChild(s);
                        })();
                    </script>
                    <noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript" rel="nofollow">comments powered by Disqus.</a></noscript>
                </div>
                <!-- aside -->
                <div class="col-md-4">
                    <!-- ad -->
                    <div class="aside-widget text-center">
                        <a href="#" style="display: inline-block;margin: auto;">
                            <img class="img-responsive" src="<?php echo e(asset('assets/front')); ?>/img/ad-1.jpg" alt="">
                        </a>
                    </div>
                    <!-- /ad -->

                    <!-- post widget -->
                    <div class="aside-widget">
                        <div class="section-title">
                            <h2>المقالات الاحدث</h2>
                        </div>

                        <?php $__currentLoopData = $secondRecentBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondRecentBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="post post-widget">
                                <a class="post-img" href="<?php echo e(route('front.blog',["id"=>$secondRecentBlog->id,"title"=>$secondRecentBlog->title])); ?>" title="<?php echo e($secondRecentBlog->title); ?>"><img src="<?php echo e(asset('uploads/blogs/'.$secondRecentBlog->photo)); ?>" style="width: 90px;height: 54px;" title="<?php echo e($secondRecentBlog->title); ?>" alt="<?php echo e($secondRecentBlog->title); ?>"></a>
                                <div class="post-body">
                                    <h3 class="post-title"><a href="<?php echo e(route('front.blog',["id"=>$secondRecentBlog->id,"title"=>$secondRecentBlog->title])); ?>" title="<?php echo e($secondRecentBlog->title); ?>"><?php echo e($secondRecentBlog->title); ?></a></h3>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <!-- /post widget -->

                    <!-- post widget -->
                    <div class="aside-widget">
                        <div class="section-title">
                            <h2>الاكثر مشاهدة</h2>
                        </div>

                        <?php $__currentLoopData = $mostWatchBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mostWatchBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="post post-widget">
                                <a class="post-img" href="<?php echo e(route('front.blog',["id"=>$mostWatchBlog->id,"title"=>$mostWatchBlog->title])); ?>" title="<?php echo e($mostWatchBlog->title); ?>"><img src="<?php echo e(asset('uploads/blogs/'.$mostWatchBlog->photo)); ?>" style="width: 90px;height: 54px;" title="<?php echo e($mostWatchBlog->title); ?>" alt="<?php echo e($mostWatchBlog->title); ?>"></a>
                                <div class="post-body">
                                    <h3 class="post-title"><a href="<?php echo e(route('front.blog',["id"=>$mostWatchBlog->id,"title"=>$mostWatchBlog->title])); ?>" title="<?php echo e($mostWatchBlog->title); ?>"><?php echo e($mostWatchBlog->title); ?></a></h3>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- /post widget -->

                    <!-- catagories -->
                    <div class="aside-widget">
                        <div class="section-title">
                            <h2>الاقسام</h2>
                        </div>
                        <div class="category-widget">
                            <ul>
                                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="<?php echo e($color[array_rand($color)]); ?>"><a href="<?php echo e(route('front.category',['id'=>$cat->id,'title'=>str_replace(' ','-',$cat->name)])); ?>" title="<?php echo e($cat->name); ?>"><?php echo e($cat->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <!-- /catagories -->

                    <!-- /archive -->
                </div>
                <!-- /aside -->
        <!-- /container -->
            </div>
        </div>
    </div>
    <!-- /section -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>

        /**
         *  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
         *  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables*/
        /*
        var disqus_config = function () {
        this.page.url = PAGE_URL;  // Replace PAGE_URL with your page's canonical URL variable
        this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
        };
        */
        (function() { // DON'T EDIT BELOW THIS LINE
            var d = document, s = d.createElement('script');
            s.src = 'https://senior-2.disqus.com/embed.js';
            s.setAttribute('data-timestamp', +new Date());
            (d.head || d.body).appendChild(s);
        })();
    </script>
    <noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript" rel="nofollow">comments powered by Disqus.</a></noscript>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/laravel_blog/resources/views/front/blog.blade.php ENDPATH**/ ?>