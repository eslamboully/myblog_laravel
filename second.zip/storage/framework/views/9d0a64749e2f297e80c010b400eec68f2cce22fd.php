<?php $__env->startSection('title'); ?> المشرفين | تعديل <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">الرئيسية</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-left">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>">الرئيسية</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.admins.index')); ?>">المشرفين</a></li>
                        <li class="breadcrumb-item active">تعديل</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">تعديل المشرف</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <form action="<?php echo e(route('admin.admins.update',$row->id)); ?>" method="post" enctype="multipart/form-data">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="name">الاسم</label>
                                            <input type="text" name="name" class="form-control" value="<?php echo e($row->name); ?>" required id="name">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="email">البريد الالكتروني</label>
                                            <input type="email" name="email" class="form-control" value="<?php echo e($row->email); ?>" required id="email">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="password">الباسورد</label>
                                            <input type="password" name="password" class="form-control" id="password">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">نبذة</label>
                                        <textarea name="description" class="form-control" id="description"><?php echo e($row->description); ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>الصورة الشخصية</label>
                                        <input type='file' id="imgInp" name="photo" hidden/>
                                        <?php if($row->photo == null): ?>
                                            <img id="blah" src="<?php echo e(asset('assets/admin/images/profile.png')); ?>" style="width: 70px;height: 70px;border-radius: 35px;" alt="your image" />
                                        <?php else: ?>
                                            <img id="blah" src="<?php echo e(asset('uploads/admins/'.$row->photo)); ?>" style="width: 70px;height: 70px;border-radius: 35px;" alt="your image" />
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <!-- Custom Tabs -->
                                    <div class="card">
                                        <div class="card-header d-flex p-0">
                                            <h3 class="card-title p-3">الصلاحيات</h3>
                                            <ul class="nav nav-pills ml-auto p-2">
                                                <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="nav-item"><a class="nav-link <?php echo e($loop->first ? 'active show' : ''); ?>" href="#<?php echo e($model); ?>" data-toggle="tab"><?php echo e($key); ?></a></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div><!-- /.card-header -->
                                        <div class="card-body">
                                            <div class="tab-content">
                                                <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="tab-pane <?php echo e($loop->first ? 'active show' : ''); ?>" id="<?php echo e($model); ?>">

                                                        <?php $__currentLoopData = $cruds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$crud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <input type="checkbox" name="permissions[]" <?php echo e($row->can($crud.'_'.$model) ? 'checked' : ''); ?> value="<?php echo e($crud); ?>_<?php echo e($model); ?>">
                                                            <label><?php echo e($key); ?></label>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                        <!-- ./card -->
                                    </div>
                                </div>
                                <button class="btn btn-success sm"><i class="fa fa-edit"></i> تعديل</button>
                            </form>
                        </div>
                        <!-- /.card-body -->

                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function(e) {
                    $('#blah').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]); // convert to base64 string
            }
        }

        $("#imgInp").change(function() {
            readURL(this);
        });
        $("#blah").on('click',function () {
            $("#imgInp").click();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/laravel_blog/resources/views/admin/admins/edit.blade.php ENDPATH**/ ?>