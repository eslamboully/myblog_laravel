<?php $__env->startSection('title'); ?> السنيور | <?php echo e($category->name); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-md-10">
                    <ul class="page-header-breadcrumb">
                        <li><a href="<?php echo e(route('front.index')); ?>" title="الرئيسية">الرئيسية</a></li>
                        <li><?php echo e($category->name); ?></li>
                    </ul>
                    <h1><?php echo e($category->name); ?></h1>
                </div>
            </div>
        </div>
    </div>
    <!-- section -->
    <div class="section">
        <!-- container -->
        <div class="container">
            <!-- row -->
            <div class="row">
                <div class="col-md-8">
                    <div class="row">
                        <!-- post -->
                        <div class="col-md-12">
                            <div class="post post-thumb">
                                <a class="post-img" href="<?php echo e(route('front.blog',["id"=>$recentBlog->id,"title"=>str_replace(' ','-',$recentBlog->title)])); ?>" title="<?php echo e($recentBlog->title); ?>"><img src="<?php echo e(asset('uploads/blogs/'.$recentBlog->photo)); ?>" style="width: 750px;height: 450px" title="<?php echo e($recentBlog->title); ?>" alt="<?php echo e($recentBlog->title); ?>"></a>
                                <div class="post-body">
                                    <div class="post-meta">
                                        <a class="post-category <?php echo e($color[array_rand($color)]); ?>" href="<?php echo e(route('front.category',["id"=>$recentBlog->category->id,"title"=>str_replace(' ','-',$recentBlog->category->name)])); ?>" title="<?php echo e($recentBlog->title); ?>"><?php echo e($recentBlog->category->name); ?></a>
                                        <span class="post-date"><?php echo e($recentBlog->created_at->diffForHumans()); ?></span>
                                    </div>
                                    <h3 class="post-title"><a href="<?php echo e(route('front.blog',["id"=>$recentBlog->id,"title"=>str_replace(' ','-',$recentBlog->title)])); ?>" title="<?php echo e($recentBlog->title); ?>"><?php echo e($recentBlog->title); ?></a></h3>
                                </div>
                            </div>
                        </div>
                        <!-- /post -->


                    <?php $__currentLoopData = $secondRecentBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondRecentBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- post -->
                            <div class="col-md-6">
                                <div class="post">
                                    <a class="post-img" title="<?php echo e($secondRecentBlog->title); ?>" href="<?php echo e(route('front.blog',["id"=>$secondRecentBlog->id,"title"=>str_replace(' ','-',$secondRecentBlog->title)])); ?>"><img src="<?php echo e(asset('uploads/blogs/'.$secondRecentBlog->photo)); ?>" style="width: 360px;height: 216px;" title="<?php echo e($secondRecentBlog->title); ?>" alt="<?php echo e($secondRecentBlog->title); ?>"></a>
                                    <div class="post-body">
                                        <div class="post-meta">
                                            <a class="post-category <?php echo e($color[array_rand($color)]); ?>" title="<?php echo e($secondRecentBlog->category->name); ?>" href="<?php echo e(route('front.category',["id"=>$secondRecentBlog->category->id,"title"=>$secondRecentBlog->category->name])); ?>" title="<?php echo e($secondRecentBlog->category->name); ?>"><?php echo e($secondRecentBlog->category->name); ?></a>
                                            <span class="post-date"><?php echo e($secondRecentBlog->created_at->diffForHumans()); ?></span>
                                        </div>
                                        <h3 class="post-title"><a href="<?php echo e(route('front.blog',["id"=>$secondRecentBlog->id,"title"=>str_replace(' ','-',$secondRecentBlog->title)])); ?>" title="<?php echo e($secondRecentBlog->category->name); ?>"><?php echo e($secondRecentBlog->title); ?></a></h3>
                                    </div>
                                </div>
                            </div>
                            <!-- /post -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="clearfix visible-md visible-lg"></div>

                        <!-- ad -->
                        <div class="col-md-12">
                            <div class="section-row">
                                <a href="#">
                                    <img class="img-responsive center-block" src="<?php echo e(asset('assets/front')); ?>/img/ad-2.jpg" alt="">
                                </a>
                            </div>
                        </div>
                        <!-- ad -->


                        <?php $__currentLoopData = $secondMostWatchBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondMostWatchBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- post -->
                            <div class="col-md-12">
                                <div class="post post-row">
                                    <a class="post-img" href="<?php echo e(route('front.blog',["id"=>$secondMostWatchBlog->id,"title"=>$secondMostWatchBlog->title])); ?>" title="<?php echo e($secondMostWatchBlog->title); ?>"><img src="<?php echo e(asset('uploads/blogs/'.$secondMostWatchBlog->photo)); ?>" style="width: 90px;height: 54px;" title="<?php echo e($secondMostWatchBlog->title); ?>" alt="<?php echo e($secondMostWatchBlog->title); ?>"></a>
                                    <div class="post-body">
                                        <div class="post-meta">
                                            <a class="post-category <?php echo e($color[array_rand($color)]); ?>" href="<?php echo e(route('front.category',["id"=>$secondMostWatchBlog->category->id,"title"=>str_replace(' ','-',$secondMostWatchBlog->category->name)])); ?>" title="<?php echo e($secondMostWatchBlog->category->name); ?>"><?php echo e($secondMostWatchBlog->category->name); ?></a>
                                            <span class="post-date"><?php echo e($secondMostWatchBlog->created_at->diffForHumans()); ?></span>
                                        </div>
                                        <h3 class="post-title"><a href="<?php echo e(route('front.blog',["id"=>$secondMostWatchBlog->id,"title"=>$secondMostWatchBlog->title])); ?>" title="<?php echo e($secondMostWatchBlog->title); ?>"><?php echo e($secondMostWatchBlog->title); ?></a></h3>
                                        <p><?php echo e(\Illuminate\Support\Str::limit($secondMostWatchBlog->description,80)); ?>...</p>
                                    </div>
                                </div>
                            </div>
                            <!-- /post -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-md-12">
                            <div class="section-row">
                                <button class="primary-button center-block">رؤية المزيد</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <!-- ad -->
                    <div class="aside-widget text-center">
                        <a href="#" style="display: inline-block;margin: auto;">
                            <img class="img-responsive" src="<?php echo e(asset('assets/front')); ?>/img/ad-1.jpg" alt="">
                        </a>
                    </div>
                    <!-- /ad -->

                    <!-- post widget -->
                    <div class="aside-widget">
                        <div class="section-title">
                            <h2>الاكثر مشاهدة</h2>
                        </div>

                        <?php $__currentLoopData = $mostWatchBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mostWatchBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="post post-widget">
                                <a class="post-img" href="<?php echo e(route('front.blog',["id"=>$mostWatchBlog->id,"title"=>$mostWatchBlog->title])); ?>" title="<?php echo e($mostWatchBlog->title); ?>"><img src="<?php echo e(asset('uploads/blogs/'.$mostWatchBlog->photo)); ?>" style="width: 90px;height: 54px;" title="<?php echo e($mostWatchBlog->title); ?>" alt="<?php echo e($mostWatchBlog->title); ?>"></a>
                                <div class="post-body">
                                    <h3 class="post-title"><a href="<?php echo e(route('front.blog',["id"=>$mostWatchBlog->id,"title"=>$mostWatchBlog->title])); ?>" title="<?php echo e($mostWatchBlog->title); ?>"><?php echo e($mostWatchBlog->title); ?></a></h3>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- /post widget -->

                    <!-- catagories -->
                    <div class="aside-widget">
                        <div class="section-title">
                            <h2>الاقسام</h2>
                        </div>
                        <div class="category-widget">
                            <ul>
                                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="<?php echo e($color[array_rand($color)]); ?>"><a href="<?php echo e(route('front.category',['id'=>$cat->id,'title'=>str_replace(' ','-',$cat->name)])); ?>" title="<?php echo e($cat->name); ?>"><?php echo e($cat->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <!-- /catagories -->

                    <!-- tags -->















                    <!-- /tags -->

                    <!-- archive -->












                    <!-- /archive -->
                </div>
            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </div>
    <!-- /section -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/laravel_blog/resources/views/front/category.blade.php ENDPATH**/ ?>